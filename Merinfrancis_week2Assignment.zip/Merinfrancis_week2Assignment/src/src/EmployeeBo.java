
public class EmployeeBo extends EmployeeVo{
public void calincomeTax(EmployeeVo e) {
		int b=e.getAnnualincome();
		e.setIncometax(b);
		;
	}

}
