
public class EmployeeMain {
	public static void main(String[] args) {
		EmployeeVo e=new EmployeeVo();
		System.out.println(e);
	}

}
