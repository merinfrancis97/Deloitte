package com;

public class Multiplication extends Arithmetic {

	@Override
	public int method(int num1,int num2) {
		return num1*num2;
		
	}

	

}
