package com;

public class Division extends Arithmetic {

	@Override
	public int method(int num1,int num2) {
		return (int)num1/num2;
		
	}

	
	

}
