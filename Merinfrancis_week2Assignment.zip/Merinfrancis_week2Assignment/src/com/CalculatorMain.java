package com;

import java.util.Scanner;

public class CalculatorMain {
	public static void main(String[] args) {
		//Scanner sc=new Scanner(System.in);

		System.out.println("####### CALCULATOR APPLICATION ######");
		System.out.println("1.ADD");
		System.out.println("2.SUBTRACT");
		System.out.println("3.MULTIPLY");
		System.out.println("4.DIVIDE");
		System.out.println("5.EXIT");
		System.out.println("enter your choice");
		Arithmetic[] fs = {new Addition(), new Subtraction(), new Multiplication(), new Division() };
		System.out.println("Enter your choice:\n1. Add\n2. Sub\n3. Multiply\n4. Divide\n");
		int input;
		Scanner sc = new Scanner(System.in);
		input = sc.nextInt();
		
		int num1, num2;//  = 12, num2 = 6;
		System.out.println("Enter the two numbers: ");
		num1 = sc.nextInt();
		num2 = sc.nextInt();
		int y = ((Arithmetic)fs[input-1]).method(num1, num2);
		System.out.println(y);
		sc.close();

		
	}
	
	}


