package com;

import java.util.Scanner;

public abstract class Arithmetic {
	   private int num1;
	   private int num2;
	  Arithmetic(){
		 
		  
	  }
	public void read() {
		System.out.println("enter the first number");
		Scanner sc=new Scanner(System.in);
		
		num1=sc.nextInt();
		System.out.println("enter the second number");
		num2=sc.nextInt();
		
	}
	public void display() {
		System.out.println("num1 = "+num1);
		System.out.println("num2 = "+num2);
	}
	public abstract int method(int x,int y);

}
