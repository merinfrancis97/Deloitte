package com.pms.deloitte.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import com.pms.deloitte.dao.ProductDAO;
import com.pms.deloitte.model.Product;
import com.pms.deloitte.service.ProductService;



@RestController
@RequestMapping("product")
public class ProductRestController {
	
	
	@Autowired
	ProductService productservice;
	@RequestMapping("getProduct")
	public List<Product> product(){
		List<Product> allListProducts=productservice.listProducts();
		return allListProducts;
	}
	
	/*@RequestMapping("/saveProduct")
	public ModelAndView saveproduct(Product product) {
		ModelAndView view=new ModelAndView("redirect:/product");
		
		view.addObject("product",new Product());
		System.out.println(product);
		productservice.addProduct(product);
		return view;
		
	}
	
	
	@RequestMapping("/product")
	public ModelAndView product() {
		
		ModelAndView view=new ModelAndView();
		view.setViewName("productForm");
		List<Product> allProducts=productservice.listProducts();
        view.addObject("allProducts",allProducts);
		view.addObject("product",new Product());
		return view;
		
	}
	@RequestMapping("deleteProduct/{prodId}")
	public ModelAndView deleteProduct(@PathVariable("prodId")Integer productId) {
		ModelAndView view=new ModelAndView("redirect:/product");
		productservice.deleteProduct(productId);
		view.addObject("product",new Product());
		
		return view;
		
	}
	@RequestMapping("editProduct/{prodId}")
	public ModelAndView editProduct(@PathVariable("prodId")Integer productId) {
		ModelAndView view=new ModelAndView("productForm");
		System.out.println();
	      Product product=productservice.getProduct(productId);
	      List<Product> allProducts=productservice.listProducts();
	      view.addObject("allProducts",allProducts);
		
		view.addObject("product",product);
		
		return view;
		
	}
	@RequestMapping("editProduct/add/update")
	public String updateProduct(Product product) {
		this.productservice.updateProduct(product);
		return "redirect:/product";
	}
	
*/
}
