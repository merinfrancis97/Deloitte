package com.rms.deloitte.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(schema="hr",name="Order")
public class Order implements Serializable{
	
	@Id
	private int orderId;
	@Column
	private String itemName;
	@Column
	private int quantity;
	@Column
	private int price;
	@Column
	private String waiterName;
	
	
	public  Order() {
		
	}


	public int getOrderId() {
		return orderId;
	}


	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}


	public String getItemName() {
		return itemName;
	}


	public void setItemName(String itemName) {
		this.itemName = itemName;
	}


	public int getQuantity() {
		return quantity;
	}


	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}


	public int getPrice() {
		return price;
	}


	public void setPrice(int price) {
		this.price = price;
	}


	public String getWaiterName() {
		return waiterName;
	}


	public void setWaiterName(String waiterName) {
		this.waiterName = waiterName;
	}


	@Override
	public String toString() {
		return "Order [orderId=" + orderId + ", itemName=" + itemName + ", quantity=" + quantity + ", price=" + price
				+ ", waiterName=" + waiterName + "]";
	}


	public Order(int orderId, String itemName, int quantity, int price, String waiterName) {
		super();
		this.orderId = orderId;
		this.itemName = itemName;
		this.quantity = quantity;
		this.price = price;
		this.waiterName = waiterName;
	}

	

}
