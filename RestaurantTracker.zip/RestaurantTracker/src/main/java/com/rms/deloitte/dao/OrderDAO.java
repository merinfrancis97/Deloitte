package com.rms.deloitte.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.pms.deloitte.model.Product;
import com.rms.deloitte.model.Order;
@Repository

public interface OrderDAO extends CrudRepository<Order, Integer> {
    public List<Order> findByWaiterName(String waiterName);
    

}
