package com.rms.deloitte.service;

import java.util.List;


import com.rms.deloitte.model.Order;

public interface OrderService {
	public void addOrder(Order order);
	public void deleteOrder(int orderId);

	public void updateOrder(Order order);

	public Order getOrder(int orderId);
	public boolean isOrderExists(int orderId);
	public List<Order> listOrders();
	public List<Order> listOrders(String waiterName);
	public void deleteOrders(String waiterName);
	



	

}