package com;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cms.deloitte.dao.ProductDAO;
import com.cms.deloitte.dao.ProductDAO;
import com.cms.deloitte.dao.impl.ProductDaoImpl;
import com.cms.deloitte.dao.impl.ProductDaoImpl;
import com.cms.deloitte.model.Product;

/**
 * Servlet implementation class ProductServlet
 */
@WebServlet("/ProductServlet")
public class ProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProductServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String productId=request.getParameter("productId");
		String productName=request.getParameter("productName");
		int qoh=Integer.parseInt(request.getParameter("qoh"));
		int price=Integer.parseInt(request.getParameter("price"));

	
		response.getWriter().println(productName+" saved succesfully");

		
		
		ProductDAO productDAO=new ProductDaoImpl();
	    Product product=new Product(productId, productName, qoh, price);
	    
	   
		productDAO.addProduct(product);
		
		response.getWriter().println("<form action=DisplayServlet>");
		response.getWriter().println("<input type=\"submit\" value=\"View products\" />");
		response.getWriter().println("</form");
		
		
		// TODO Auto-generated method stub
	}

}
