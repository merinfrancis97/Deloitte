package com.cms.deloitte.client;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		while(true) {
		 LaunchCustomerApplication.startCustomerApp();
	}
	}

}
