package com.cms.deloitte.client;

import java.util.List;
import java.util.ArrayList;
import java.util.Scanner;

import com.cms.deloitte.dao.CustomerDAO;
import com.cms.deloitte.dao.ProductDAO;
import com.cms.deloitte.dao.impl.CustomerDaoImpl;
import com.cms.deloitte.dao.impl.ProductDaoImpl;
import com.cms.deloitte.model.Customer;

public class LaunchProductApplication {
	public static void startCustomerApp() {
		
		
		ProductDAO customerDAO=new ProductDaoImpl();
		
		System.out.println("\n##welcome to customer App##(Hibernate)");
		System.out.println("##1.Add Customer##");
		System.out.println("##2.Update Customer##");
		System.out.println("##3.delete");
		System.out.println("##4.list Customers##");
		System.out.println("##5.fetch a single customer details##");
		System.out.println("##6.check if customer exists##");
		System.out.println("##7.EXIT##");
		Scanner sc=new Scanner(System.in);
		System.out.println("enter your choice 1-6");
		int choice=sc.nextInt();
		switch(choice) {
		
			case 1:{
				   
				 Customer customer=new Customer();
				 customer.acceptCustomerDetails();
				 boolean result=false;
				 if(customerDAO.isCustomerExists(customer.getCustomerId())) {
					 System.out.println(customer.getCustomerId()+" exists");
				 }
				 else {
				      customerDAO.addCustomer(customer);
				 System.out.println(customer.getCustomerId()+" added succesfully");
				 }
				 break;
		
			
			case 4:{
				List<Customer> allCustomers=new ArrayList<Customer>();
				allCustomers=customerDAO.listCustomers();
				System.out.println(allCustomers);
				
				
				break;
			}
			