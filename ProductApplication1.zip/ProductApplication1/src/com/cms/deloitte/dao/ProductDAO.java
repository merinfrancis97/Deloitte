package com.cms.deloitte.dao;

import java.util.List;

import com.cms.deloitte.model.Product;
import com.cms.deloitte.model.Product;

public interface ProductDAO {
	public boolean addProduct(Product product);

	public List<Product> listproducts();
	public boolean isProductExists(int productId);

	
}
