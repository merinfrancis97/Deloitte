package com.cms.deloitte.dao.impl;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;



import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.cms.deloitte.dao.ProductDAO;
import com.cms.deloitte.dao.ProductDAO;
import com.cms.deloitte.model.Product;
import com.cms.deloitte.model.Product;




public class ProductDaoImpl implements ProductDAO{
	Configuration configuration=null;

SessionFactory factory=null;
public ProductDaoImpl() {
	 configuration=new Configuration().configure();
	 factory=configuration.buildSessionFactory();}
	

	@Override
	public boolean addProduct(Product product) {
		Configuration configuration=new Configuration().configure();
		SessionFactory factory=configuration.buildSessionFactory();
		Session session=factory.openSession();
		Transaction transaction=session.beginTransaction();
		session.save(product);
		transaction.commit();
		
		
		return false;
	}

	@Override
	public List<Product> listproducts() {
		
		Session session=factory.openSession();
		Query query=session.createQuery("from Product");
		return  query.list();
	}


	@Override
	public boolean isProductExists(int productId) {
		
		System.out.println(productId);
		Session session=factory.openSession();		

//		System.out.println("jhjfdij");

		Product product=new Product();
		product=(Product) session.get(Product.class, productId);
		//System.out.println("jij");
		session.close();
		if(product==null) {
			
		//System.out.println("null");
		return false;
	}
		else {
			//System.out.println("not null");
			return true;
		
		
		}
		
		// TODO Auto-generated method stub
		
		// TODO Auto-generated method stub
		
	}
	
  
	}
