package com.rms.deloitte.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;


import com.rms.deloitte.model.Order;
import com.rms.deloitte.service.OrderService;

@Controller
public class OrderController {
	
	@Autowired
	OrderService orderService;
	
	@RequestMapping("/index")
	public ModelAndView index() {
		ModelAndView view=new ModelAndView();
		view.setViewName("index");
		return view;
	}
	@RequestMapping("/paymentForm")
	public ModelAndView paymentForm() {
		ModelAndView view=new ModelAndView("paymentForm");
		view.addObject("order", new Order());
		return view;
	}
	@RequestMapping("/admin")
	public ModelAndView admin() {
		ModelAndView view=new ModelAndView();
		view.setViewName("admin");
		return view;
	}
	@RequestMapping("/waiter")
	public ModelAndView waiter() {
		ModelAndView view=new ModelAndView("waiter");
		view.addObject("order", new Order());
		return view;
	}
	@RequestMapping("/orderForm")
	public ModelAndView orderForm() {
		ModelAndView view=new ModelAndView("orderForm");
		view.addObject("order", new Order());
		return view;
	}
	@RequestMapping("/addOrder")
	public ModelAndView addOrder(Order order) 
	{
		ModelAndView view=new ModelAndView("redirect:/orderForm");
		view.addObject("order", new Order());
		orderService.addOrder(order);
		return view;
	}
	@RequestMapping("/displayOrders")
	public ModelAndView displayOrders(Order order)
	{
		ModelAndView view=new ModelAndView("display");
		List<Order> allOrders=orderService.listOrders();
		System.out.println(allOrders);
		view.addObject("allOrders", allOrders);
		return view;
	}
	@RequestMapping("/paymentOrder")
	public ModelAndView paymentOrder(HttpSession session, @RequestParam("waiterName")String waiterName)
	{
		session.setAttribute("waiterName", waiterName);
		ModelAndView view=new ModelAndView("payment");
		List<Order> findOrder=orderService.listOrders(waiterName);
		view.addObject("findOrder",findOrder );
		return view;
	}
	@RequestMapping("/paymentView")
	public ModelAndView paymentView(@RequestParam("waiterName")String waiterName)
	{
		ModelAndView view=new ModelAndView("paymentView");
		List<Order> findOrder=orderService.listOrders(waiterName);
		view.addObject("findOrder",findOrder );
		return view;
	}
	@RequestMapping("/delete")
	public ModelAndView deleteOrder(HttpSession session) {
		String waiterName= (String)session.getAttribute("waiterName");
		orderService.deleteOrders(waiterName);
		ModelAndView view=new ModelAndView("payment");
		List<Order> findOrder=orderService.listOrders(waiterName);
		view.addObject("findOrder",findOrder );
		return view;
	}
}
