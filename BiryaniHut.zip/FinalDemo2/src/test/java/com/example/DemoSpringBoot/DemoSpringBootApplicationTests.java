package com.example.DemoSpringBoot;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
